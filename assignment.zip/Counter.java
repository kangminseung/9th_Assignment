package assignment;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class MyCounter extends JFrame implements ActionListener {
	private JLabel label, label1;
	private JButton button1, button2, button3;
	private int count = 0;

	public MyCounter() {
		JPanel panel = new JPanel();
		label = new JLabel("Counter");
		panel.add(label);
		label1 = new JLabel("" + count);
		label1.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 100));
		panel.add(label1);
		JPanel panel_b = new JPanel();
		button1 = new JButton("Counter Increase");
		button2 = new JButton("Counter Reduce");
		button3 = new JButton("Counter Initialization");
		panel_b.add(button1);
		panel_b.add(button2);
		panel_b.add(button3);
		panel.add(panel_b);
		button1.addActionListener(this);
		button2.addActionListener(this);
		button3.addActionListener(this);
		add(panel);
		setSize(500, 300);
		setTitle("My Counter");
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource() == button1) {
			count++;
			label1.setText(count + "");
		} else if (event.getSource() == button2) {
			count--;
			label1.setText(count + "");
		} else {
			count = 0;
			label1.setText(count + "");
		}
	}
}

public class Counter {
	public static void main(String args[]) {
		new MyCounter();
	}
}